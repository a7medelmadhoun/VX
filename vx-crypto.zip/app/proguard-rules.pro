# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.
#
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

# If your project uses WebView with JS, uncomment the following
# and specify the fully qualified class name to the JavaScript interface
# class:
#-keepclassmembers class fqcn.of.javascript.interface.for.webview {
#   public *;
#}

# Uncomment this to preserve the line number information for
# debugging stack traces.
#-keepattributes SourceFile,LineNumberTable

# Security & Obfuscation
-renamesourcefileattribute SourceFile
-keepattributes !SourceFile,!LineNumberTable
-repackageclasses ''
-allowaccessmodification
-keeppackagenames com.example.ui.**

# Keep Moshi models
-keepclassmembers class * {
    @com.squareup.moshi.Json *;
}
-keep class com.example.api.** { *; }
-keep class com.example.data.** { *; }
